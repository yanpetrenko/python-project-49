# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Brain-games',
    'long_description': '<a href="https://codeclimate.com/github/yanpetrenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ba1a5d38fdf6956ad756/maintainability" /></a>\n\nbrain-even https://asciinema.org/a/FWE1adUO9Ovb5QpJhNxuO110K\n\nbrain-calc https://asciinema.org/a/qxMT0fRkSPcfg6hgVjWsK1Ju1\n\nbrain-gcd https://asciinema.org/a/uwOctAtwSlfkkIQFedBmno0By\n\nbrain-progression https://asciinema.org/a/hw4a42VwjLokLE4tJIxB1VmoX\n\nbrain-prime https://asciinema.org/a/17tk4NUpoir432ZU6cKpYnnJp\n',
    'author': 'yanpetrenko',
    'author_email': 'yanpetrenko@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/yanpetrenko/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.10,<4.0.0',
}


setup(**setup_kwargs)
