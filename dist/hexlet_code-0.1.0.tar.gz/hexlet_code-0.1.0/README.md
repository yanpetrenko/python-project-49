<a href="https://codeclimate.com/github/yanpetrenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ba1a5d38fdf6956ad756/maintainability" /></a>
