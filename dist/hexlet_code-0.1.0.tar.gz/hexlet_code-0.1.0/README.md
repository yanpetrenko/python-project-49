<a href="https://codeclimate.com/github/yanpetrenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ba1a5d38fdf6956ad756/maintainability" /></a>

brain-even https://asciinema.org/a/vC1jCz2aydRSPbjWtU7wom8y1

brain-calc https://asciinema.org/a/Z5qpBMudBLLh1xLCqKQN8NZ40

brain-gcd https://asciinema.org/a/cRjKE17F07AkirJOnl0dOzxTO

brain-progression https://asciinema.org/a/ZER0i21FG27mGgg2nXNbGuSZf

brain-prime https://asciinema.org/a/tnYNvAnDGjPq91lrvUxNUdogK
