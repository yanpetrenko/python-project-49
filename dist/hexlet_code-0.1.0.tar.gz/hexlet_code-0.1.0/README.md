<a href="https://codeclimate.com/github/yanpetrenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ba1a5d38fdf6956ad756/maintainability" /></a>

brain-even https://asciinema.org/a/FWE1adUO9Ovb5QpJhNxuO110K

brain-calc https://asciinema.org/a/qxMT0fRkSPcfg6hgVjWsK1Ju1

brain-gcd https://asciinema.org/a/uwOctAtwSlfkkIQFedBmno0By

brain-progression https://asciinema.org/a/hw4a42VwjLokLE4tJIxB1VmoX

brain-prime https://asciinema.org/a/17tk4NUpoir432ZU6cKpYnnJp
